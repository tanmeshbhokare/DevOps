

package devops.ilp1;
public interface IntegrationTest {

}
